import { Progress } from "@/components/ui/progress"
import { FaCheckCircle, FaExclamationCircle } from "react-icons/fa";
import { GrInProgress } from "react-icons/gr";
import { Button } from "@/components/ui/button";
import { MdCancel } from "react-icons/md";
import { HiArrowPath } from "react-icons/hi2";
import type { ColumnDef } from "@tanstack/react-table";

export type Person = {
    Object: string,
    Category: string,
    Type: String,
    Media: String,
    status: string,
    progress: string,
    index: string,
    date: string,
    srcdes: string,
}

const statusCall = (status: string) => {
    switch (status) {
        case "Completed":
            return (
                <span className='flex cols-2 '>
                    <div className="col-span-1 pr-1">
                        <FaCheckCircle className='text-[#4c9d6d] inline-block ' />
                    </div>
                    <div className="col-span-1">
                        Completed
                    </div>
                </span>
            )
        case "Aborted":
            return (
                <span className='flex cols-2  '>
                    <div className="col-span-1 pr-1">
                        <FaExclamationCircle className='text-[#ff3842] inline-block ' />
                    </div>
                    <div className="col-span-1">
                        Aborted
                    </div>
                </span>
            )
        case "Processing":
            return (
                <span className='flex cols-2  '>
                    <div className="col-span-1 pr-1">
                        <HiArrowPath className='text-[#06b3ac] stroke-2 inline-block text-[17px]  animate-spin-slow' />
                    </div>
                    <div className="col-span-1">
                        Processing
                    </div>
                </span>
            )
        case "Waiting for Resources":
            return (
                <span className='flex cols-2  '>
                    <div className="col-span-1 pr-1">
                        <GrInProgress className='text-[#28a5ad] inline-block animate-spin-slow' />
                    </div>
                    <div className="col-span-1">
                        Waiting
                    </div>
                </span>
            )
        case "Cancelled":
            return (
                <span className='flex cols-2  '>
                    <div className="col-span-1 pr-1">
                        <MdCancel className='text-[#ff3842] inline-block' />
                    </div>
                    <div className="col-span-1">
                        Cancelled
                    </div>
                </span>
            )
        default:
            break;
    }
}

export const columns: ColumnDef<Person>[] = [
    {
        accessorKey: 'UUID',
        cell: (info: any) => { return (<span className="tableHeaderSize wrapword" title={info.getValue()}>{info.getValue()}</span>) },
        header: ({ column }) => {
            return (<>
                <Button
                    variant="ghost" className="font-bold tableHeaderSize wrapword"
                >
                    Barcode
                </Button>
            </>
            )
        },
        invertSorting: true,
        size: 520
    },
    {
        accessorKey: 'UUID_path',
        cell: (info: any) => { return (<span className="tableHeaderSize" title={info.getValue()}>{info.getValue()}</span>) },
        header: ({ column }) => {
            return (<>
                <Button
                    variant="ghost" className="font-bold tableHeaderSize wrapword"
                >
                    UUID Path
                </Button>
            </>
            )
        },
        meta: {
            filterVariant: 'calender',
        },
        size: 170
    },
    {
        accessorKey: 'total_file_size',
        cell: (info: any) => { return (<span className="tableHeaderSize" title={info.getValue()}>{info.getValue()}</span>) },
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    File Size

                </Button>
            )
        },
        enableColumnFilter: true,
        meta: {
            filterVariant: 'select',
        },
        size: 60
    },
    {
        accessorKey: 'total_file_count',
        cell: (info: any) => {
            return (<span className="tableHeaderSize wrapword" title={info.getValue()}>{info.getValue()}</span>)
        },
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    Total File
                </Button>
            )
        },
        size: 50,
        enableColumnFilter: false,
    },
    {
        accessorKey: 'migrated_file_count',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    File Count

                </Button>
            )
        },
        cell: (info: any) => {
            return (<span className="tableHeaderSize wrapword" title={info.getValue()}>{info.getValue()}</span>)
        },
        size: 50,
        minSize: 120
    },
    // {
    //     accessorKey: 'migrated_file_size',
    //     cell: (info: any) => { return (<span className="tableHeaderSize" title={info.getValue()}>{info.getValue()}</span>) },
    //     header: ({ column }) => {
    //         return (
    //             <Button
    //                 variant="ghost" className="font-bold tableHeaderSize "
    //             >
    //                 Migrated Size
    //             </Button>
    //         )
    //     },
    //     meta: {
    //         filterVariant: 'select',
    //     },
    //     size: 60,
    //     minSize: 70,
    // },
    {
        accessorKey: 'migration_status',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    Status
                </Button>
            )
        },
        cell: (info: any) => {
            return (<span className="tableHeaderSize" title={info.getValue()}>{info.getValue()}</span>)
        },
        enableSorting: false,
        enableColumnFilter: false,
        size: 106
    },
    {
        accessorKey: 'Migration_Start_Date',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    Start Date
                </Button>
            )
        },
        cell: (info: any) => {
            return (<span className="tableHeaderSize wrapword" title={info.getValue()?.split("T")[0]}>{info.getValue()?.split("T")[0]}</span>)
        },
        enableSorting: false,
        enableColumnFilter: false,
        size: 80
    },
    {
        accessorKey: 'Migration_End_Date',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    End Date
                </Button>
            )
        },
        cell: (info: any) => {
            return (<span className="tableHeaderSize wrapword" title={info.getValue()?.split("T")[0]}>{info.getValue()?.split("T")[0]}</span>)
        },
        enableSorting: false,
        enableColumnFilter: false,
        size: 106
    },
    {
        accessorKey: 'Invoice_Generated',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    Invoice
                </Button>
            )
        },
        cell: (info: any) => {
            return (<span className="tableHeaderSize wrapword" title={info.getValue()}>{info.getValue()}</span>)
        },
        enableSorting: false,
        enableColumnFilter: false,
        size: 35
    },
    {
        accessorKey: 'Invoice_Generation_Date',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    Invoice Date
                </Button>
            )
        },
        cell: (info: any) => {
            return (<span className="tableHeaderSize wrapword" title={info.getValue()?.split("T")[0]}>{info.getValue()?.split("T")[0]}</span>)
        },
        enableSorting: false,
        enableColumnFilter: false,
        size: 70
    },
    {
        accessorKey: 'Verified',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize"
                >
                    Verified
                </Button>
            )
        },
        cell: (info: any) => {
            return (<span className="tableHeaderSize wrapword" title={info.getValue()}>{info.getValue()}</span>)
        },
        enableSorting: false,
        enableColumnFilter: false,
        size: 55
    },
    // {
    //     accessorKey: 'Remarks',
    //     header: ({ column }) => {
    //         return (
    //             <Button
    //                 variant="ghost" className="font-bold tableHeaderSize"
    //             >
    //                 Remarks
    //             </Button>
    //         )
    //     },
    //     cell: (info: any) => {
    //         return (<span className="tableHeaderSize wrapword" title={info.getValue()}>{info.getValue()}</span>)
    //     },
    //     enableSorting: false,
    //     enableColumnFilter: false,
    //     size: 55
    // },
    {
        accessorKey: 'migration_progress_percent',
        header: ({ column }) => {
            return (
                <Button
                    variant="ghost" className="font-bold tableHeaderSize "
                >
                    Progress
                </Button>
            )
        },
        cell: (info: any) => { return (<div className="py-1"><Progress value={info.getValue()} className="flex justify-center" /></div>) },
        enableSorting: false,
        enableColumnFilter: false,
        size: 106
    },
]
