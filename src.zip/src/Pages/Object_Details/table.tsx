import {
    flexRender,
    getCoreRowModel,
    useReactTable,
    getPaginationRowModel,
} from '@tanstack/react-table';
import React, { Fragment, useCallback, useMemo, useRef, useState } from 'react';
import { columns } from './HandleApiCall/columns';
import { Skeleton } from '@/components/ui/skeleton';
import { FaSortUp, FaSortDown } from "react-icons/fa6";
import { useQuery } from '@tanstack/react-query';
import { fetchData } from './HandleApiCall/Apicall';


const Tabledata = () => {

    const divRef = useRef<HTMLDivElement>(null);
    const { data, isLoading, refetch, error } = useQuery({
        queryKey: ['requestData'],
        queryFn: () => {
            const endpoint = `http://localhost:4000/objects`
            return fetchData<any>(endpoint);
        },
        networkMode: 'always',
        refetchInterval: 20000,
        retry: false
    });



    const tableData = useMemo(() =>
        (isLoading === true ? Array(10).fill({}) : data),
        [isLoading, data]
    );

    const tableColumns = useMemo(
        () =>
            isLoading === true
                ? columns.map((column) => ({
                    ...column,
                    cell: () => (
                        <div className="flex flex-col space-y-3">
                            <Skeleton className="h-[20px] w-full rounded-xl mt-1" />
                        </div>
                    )
                }))
                : columns,
        [isLoading]
    );


    const table = useReactTable({
        data: tableData ?? [],
        columns: tableColumns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        manualPagination: true,
        enableColumnResizing: true,
        columnResizeMode: 'onChange',
        enableMultiRowSelection: false,
        manualSorting: true,
        enableSortingRemoval: false, //Don't allow - default on/true 
    });


    return (<>
        <div
            className="h-[94%] 2xl:w-[100%] lg:w-full overflow-auto lg:text-sm 2xl:text-base"
            style={{ direction: table.options.columnResizeDirection }}
            ref={divRef}
        >

            <table className='w-full' >
                <thead>
                    {table.getHeaderGroups().map(headerGroup => (
                        <Fragment key={headerGroup.id}>
                            <tr>
                                {headerGroup.headers.map(header => {
                                    return (
                                        <th
                                            key={header.id}
                                            colSpan={header.colSpan}
                                            style={{ position: 'relative', width: header.getSize(), fontSize: "clamp(0.8rem, 1.5vw, 1rem)" }}
                                            className="th select-none px-1.5 text-black dark:text-white sticky top-0 dark:bg-[#2d3d52] bg-slate-50 dark:drop-shadow-1 drop-shadow-md"
                                        >
                                            <div className="flex justify-between items-center w-full">
                                                <span
                                                    className={`flex items-center hover:border-r hover:border-[#414954] ${header.column.getCanFilter() ? 'w-[100%]' : 'w-[100%]'}`}
                                                    onClick={header.column.getToggleSortingHandler()}
                                                >
                                                    <span className='w-[70%]'> {flexRender(header.column.columnDef.header, header.getContext())}</span>
                                                    <span className="pt-1 w-[30%] flex justify-end ">
                                                        {{
                                                            asc: <FaSortUp className="h-4 w-4 font-bold" />,
                                                            desc: <FaSortDown className="h-4 w-4 font-bold" />,
                                                        }[header.column.getIsSorted() as string] ?? null}
                                                    </span>
                                                </span>
                                            </div>
                                            {header.column.getCanResize() && (
                                                <div
                                                    onDoubleClick={() => header.column.resetSize()}
                                                    onMouseDown={header.getResizeHandler()}
                                                    onTouchStart={header.getResizeHandler()}
                                                    className={`resizer ${header.column.getIsResizing() ? 'isResizing' : ''
                                                        }`}
                                                ></div>
                                            )}
                                        </th>
                                    )
                                })}
                            </tr>
                        </Fragment>
                    ))}
                </thead>
                <tbody>
                    {table.getRowModel().rows.map(row => {
                        return (
                            <tr
                                key={row.index}
                                id={`row-${row.index}`}
                                className={`font-medium h-7  text-white odd:bg-[#24303f] h-7  even:bg-[#2d3d52]`}
                            >
                                {row.getVisibleCells().map(cell => {
                                    return (
                                        <td key={cell.id} style={{ width: cell.column.getSize() }} className='px-1'>
                                            {flexRender(
                                                cell.column.columnDef.cell,
                                                cell.getContext()
                                            )}
                                        </td>
                                    )
                                })}
                            </tr>
                        )
                    })}
                </tbody>
            </table>
        </div >
    </>
    )
}

export default React.memo(Tabledata)